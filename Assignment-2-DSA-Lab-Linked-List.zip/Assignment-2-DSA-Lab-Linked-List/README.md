# Data Structures and Algorithms Lab  
## Assignment 2 – Linked List Implementation  

👨‍🎓 Name: Your Name  
🆔 SAP ID: Your SAP ID  
📚 Course: B.Tech CSE (Sem II)  
📘 Subject: DSA Lab  
📅 Date: 17 February 2026  

---

## 📌 Experiment 2  
To experiment with pointers, structures, and dynamic memory allocation to implement different types of linked lists.

---

## ✅ Programs Included

1. Count number of nodes in Singly Linked List  
2. Search element in Singly Linked List  
3. Insertion operations in Singly Linked List  
4. Deletion operations in Singly Linked List  
5. Reverse data of nodes in Singly Linked List  
6. Circular Singly Linked List  
7. Doubly Linked List  
8. Doubly Circular Linked List  
9. Polynomial using Linked List  
10. Student Record using Linked List  

---

## ▶️ How to Run

gcc filename.c
./a.out
